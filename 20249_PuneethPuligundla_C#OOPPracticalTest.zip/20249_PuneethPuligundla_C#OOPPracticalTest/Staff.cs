using System;
using System.Collections.Generic;
using System.Text;
/// <summary>
/// The Staff Class Of the Given Problem Statement
/// </summary>
namespace PracticalTest
{
    public class Staff : Employee
    {
        public string title { get; set; }

        public Staff(int id, string name, string add, double pay, string title) : base(id, name, add, pay)
        {
            this.title = title;
        }

        public override double calcSal()                              ///<remarks> calcSal() has been overridden in 2nd Child class </remarks>
        {
            return bpay + (bpay * 0.18);                              ///<remarks>HRA added to basic sal of employee</remarks>
        }

        public override string ToString()
        {
            return $"Empd->{this.eid},EmpName->{this.ename},Address->{this.address},Title->{this.title}, Pay-> {calcSal()}";
        }



    }
}
