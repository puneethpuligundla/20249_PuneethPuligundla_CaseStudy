using System;
using System.Collections.Generic;
using System.Text;
/// <summary>
/// The Technical Employee Class Of the Given Problem Statement
/// </summary>
public class TechEmp : Employee
    {
        public string[] skills;

        public TechEmp()
        {
            skills = new string[10];
        }

        public TechEmp(int id,string name,string add, double pay,string[] skill) : base(id, name, add, pay)
        {
            this.skills = skill;
        }

        public override double calcSal()                     ///<remarks>calcSal() has been overridden in 1st child class</remarks>
        {
            return bpay+(bpay*0.12);                         ///<remarks>HRA added to basic sal of employee</remarks>
        }

        public override string ToString()
        {
            return $"Empd->{this.eid},EmpName->{this.ename},Address->{this.address},Skills->{string.Join(",",this.skills)}, Pay-> {calcSal()}";
        }


    }