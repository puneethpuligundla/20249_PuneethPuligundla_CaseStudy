using System;
using System.Collections.Generic;
using System.Text;
/// <summary>
/// The Driver Class Of the given Problem Statement
/// </summary>
namespace PracticalTest
{
    public class UsingPeople                                      ///<remarks>//Driver class for o/p Demonstration</remarks>
    {
        public static void Main(string[] args)
        {
            TechEmp t1 = new TechEmp(20249, "Puneeth", "Bangalore", 30000, new string[] { "Java", "C#", "HTML" });
            Console.WriteLine(t1.ToString());

           try
            {
                Console.WriteLine(t1.skills[11]);
            }catch(FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(NotFiniteNumberException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("The Code has been executed Successfully"); 
            }

        }
    }
}