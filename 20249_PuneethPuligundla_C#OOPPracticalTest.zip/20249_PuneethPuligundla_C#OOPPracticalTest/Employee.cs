using System;

/// <summary>
/// The Abstract Employee Class Of the Given Problem Statement
/// </summary>

namespace PracticalTest
{
    public abstract class Employee
    {
        public int eid { get; set; }
        public string ename { get; set; }
        public string address { get; set; }

        public double bpay { get; set; }
        public abstract double calcSal();                        /// <<remarks>abstract method calcSal() has been created</remarks>

        public Employee()
        {

        }
        public Employee(int id,string name,string add,double pay)  ///<remarks>Employee class constructor</remarks>
        {
            this.eid = id;
            this.ename = name;
            this.address = add;
            this.bpay = pay;

        }
        
    }